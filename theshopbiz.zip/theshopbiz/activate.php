<?php
OW::getNavigation()->addMenuItem(OW_Navigation::BOTTOM, 'theshopbiz.index', 'theshopbiz', '+', OW_Navigation::VISIBLE_FOR_ALL);
?>