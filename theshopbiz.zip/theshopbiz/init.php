<?php
OW::getRouter()->addRoute(new OW_Route('theshopbiz.index', 'theshop', "THESHOPBIZ_CTRL_Theshop", 'index'));
?>