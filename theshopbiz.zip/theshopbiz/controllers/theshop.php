<?php
class THESHOPBIZ_CTRL_Theshop extends OW_ActionController 
{ 
public function index() 
    { 
        $this->setPageTitle("The Shop Biz"); 
        $this->setPageHeading("The Shop Biz"); 
    } 
}
?>