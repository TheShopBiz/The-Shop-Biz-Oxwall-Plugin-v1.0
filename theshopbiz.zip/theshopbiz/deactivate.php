<?php
OW::getNavigation()->deleteMenuItem('theshopbiz', '+');
OW::getNavigation()->deleteMenuItem('theshopbiz', 'bottom_menu_item');
?>